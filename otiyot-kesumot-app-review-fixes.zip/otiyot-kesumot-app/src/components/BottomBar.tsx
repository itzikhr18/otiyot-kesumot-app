import React from 'react';
import { HelpIcon, StarIcon } from './Icons';
import { useApp } from '../context/AppContext';
import { playClick } from '../lib/audio';

type Mood = 'neutral' | 'happy' | 'encourage' | 'think' | 'celebrate';

export function BottomBar({ mood = 'neutral' }: { mood?: Mood }) {
  const { progress, repeatInstruction } = useApp();
  const base = import.meta.env.BASE_URL;
  const owlSrc = `${base}assets/owl/${mood}.svg`;

  return (
    <div className="bottom" role="contentinfo">
      <div className="owl">
        <img src={owlSrc} alt="" />
      </div>

      <div className="stars" aria-label="כוכבים">
        <StarIcon size={22} />
        <span>{progress.totalStars}</span>
      </div>

      <button
        className="icon-btn"
        aria-label="עזרה"
        onClick={async () => {
          playClick();
          await repeatInstruction();
        }}
      >
        <HelpIcon />
      </button>
    </div>
  );
}
