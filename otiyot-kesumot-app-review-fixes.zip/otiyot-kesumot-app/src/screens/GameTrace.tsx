import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ALL_LETTERS, LETTERS_BY_CHAR, getUnlockedLetterChars } from '../data/letters';
import { useApp } from '../context/AppContext';
import { Confetti } from '../components/Confetti';
import { nextFromBag } from '../lib/bag';
import { playClick, playError, playSuccess } from '../lib/audio';

type Pt = { x: number; y: number };

type CanvasSpec = {
  cssW: number;
  cssH: number;
  dpr: number;
};

type MaskInfo = {
  spec: CanvasSpec;
  // RGBA data of an offscreen canvas with the letter drawn in black
  data: Uint8ClampedArray;
  pxW: number;
  pxH: number;
  cellSize: number; // in CSS px
  totalLetterCells: number;
  startPt: Pt | null; // in CSS px
};

function clamp(n: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, n));
}

function alphaAtCss(mask: MaskInfo, xCss: number, yCss: number): number {
  const x = Math.floor(clamp(xCss, 0, mask.spec.cssW - 1) * mask.spec.dpr);
  const y = Math.floor(clamp(yCss, 0, mask.spec.cssH - 1) * mask.spec.dpr);
  const idx = (y * mask.pxW + x) * 4 + 3;
  return mask.data[idx] ?? 0;
}

function buildLetterMask(letterChar: string, spec: CanvasSpec): MaskInfo | null {
  if (!spec.cssW || !spec.cssH) return null;

  const off = document.createElement('canvas');
  off.width = Math.floor(spec.cssW * spec.dpr);
  off.height = Math.floor(spec.cssH * spec.dpr);
  const ctx = off.getContext('2d');
  if (!ctx) return null;

  // draw in CSS coordinates
  ctx.setTransform(spec.dpr, 0, 0, spec.dpr, 0, 0);
  ctx.clearRect(0, 0, spec.cssW, spec.cssH);

  const fontSize = Math.min(spec.cssW, spec.cssH) * 0.78;
  const y = spec.cssH / 2 + fontSize * 0.06;

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = 'rgba(0,0,0,1)';
  ctx.strokeStyle = 'rgba(0,0,0,1)';
  ctx.font = `900 ${fontSize}px 'Noto Sans Hebrew', system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif`;

  // Fill + thick stroke creates a generous "track" area
  ctx.fillText(letterChar, spec.cssW / 2, y);
  ctx.lineWidth = Math.max(10, fontSize * 0.10);
  ctx.lineJoin = 'round';
  ctx.strokeText(letterChar, spec.cssW / 2, y);

  const img = ctx.getImageData(0, 0, off.width, off.height);
  const data = img.data;

  const cellSize = 14;
  let totalLetterCells = 0;

  // count how many grid cells belong to the letter mask
  for (let cy = 0; cy < spec.cssH; cy += cellSize) {
    for (let cx = 0; cx < spec.cssW; cx += cellSize) {
      const xCss = cx + cellSize / 2;
      const yCss = cy + cellSize / 2;
      if (alphaAtCss({ spec, data, pxW: off.width, pxH: off.height, cellSize, totalLetterCells: 0, startPt: null }, xCss, yCss) > 10) {
        totalLetterCells += 1;
      }
    }
  }

  // find an automatic "start" point - top-most, and as-right-as-possible
  let startPt: Pt | null = null;
  outer: for (let py = 0; py < off.height; py += 2) {
    for (let px = off.width - 1; px >= 0; px -= 2) {
      const idx = (py * off.width + px) * 4 + 3;
      if ((data[idx] ?? 0) > 10) {
        startPt = { x: px / spec.dpr, y: py / spec.dpr };
        break outer;
      }
    }
  }

  return {
    spec,
    data,
    pxW: off.width,
    pxH: off.height,
    cellSize,
    totalLetterCells: Math.max(1, totalLetterCells),
    startPt,
  };
}

export default function GameTrace() {
  const [search] = useSearchParams();
  const forcedTarget = search.get('target') ? decodeURIComponent(search.get('target') as string) : null;

  const { progress, addStars, incrementGame, markMastery, speakInstruction, speakFeedback } = useApp();

  const unlockedChars = useMemo(() => Array.from(getUnlockedLetterChars(progress.totalStars)), [progress.totalStars]);
  const allChars = useMemo(() => ALL_LETTERS.map((l) => l.char), []);
  const available = unlockedChars.length > 0 ? unlockedChars : allChars;

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [canvasSpec, setCanvasSpec] = useState<CanvasSpec>({ cssW: 0, cssH: 0, dpr: 1 });

  const maskRef = useRef<MaskInfo | null>(null);

  const [target, setTarget] = useState<string>('');

  const [mode, setMode] = useState<'guided' | 'free'>('guided');

  const pointsRef = useRef<Pt[]>([]);
  const isDownRef = useRef(false);
  const lastRef = useRef<Pt | null>(null);

  // guided stats (refs for performance + state for UI)
  const guidedVisitedRef = useRef<Set<string>>(new Set());
  const guidedInsideRef = useRef({ inside: 0, total: 0 });
  const rafRef = useRef<number | null>(null);

  const [guidedCoverage, setGuidedCoverage] = useState(0);
  const [guidedInsideRatio, setGuidedInsideRatio] = useState(0);
  const [guidedStartPt, setGuidedStartPt] = useState<Pt | null>(null);

  const [locked, setLocked] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  function pickNextTarget(): string {
    if (forcedTarget) return forcedTarget;
    const items = available.map((c) => ({ id: c, char: c }));
    return nextFromBag('trace/letters', items).char;
  }

  function resizeCanvas() {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();

    canvas.width = Math.floor(rect.width * dpr);
    canvas.height = Math.floor(rect.height * dpr);

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = 14;
    ctx.strokeStyle = 'rgba(17,24,39,0.85)';

    setCanvasSpec({ cssW: rect.width, cssH: rect.height, dpr });
  }

  function clearBoard() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    pointsRef.current = [];
    lastRef.current = null;

    guidedVisitedRef.current = new Set();
    guidedInsideRef.current = { inside: 0, total: 0 };
    setGuidedCoverage(0);
    setGuidedInsideRatio(0);
  }

  function scheduleGuidedUIUpdate() {
    if (rafRef.current) return;
    rafRef.current = window.requestAnimationFrame(() => {
      rafRef.current = null;
      const mask = maskRef.current;
      if (!mask) return;
      const visited = guidedVisitedRef.current.size;
      const cov = visited / mask.totalLetterCells;
      const st = guidedInsideRef.current;
      const ratio = st.total > 0 ? st.inside / st.total : 0;
      setGuidedCoverage(cov);
      setGuidedInsideRatio(ratio);
    });
  }

  function setNewLetter(next?: string) {
    const t = next ?? pickNextTarget();
    setTarget(t);
    setLocked(false);
    clearBoard();

    const name = LETTERS_BY_CHAR[t]?.name ?? t;
    if (mode === 'guided') {
      speakInstruction(`בוא נעקוב עם האצבע אחרי האות ${name}. התחל מהנקודה.`);
    } else {
      speakInstruction(`בוא נכתוב את האות ${name}.`);
    }
  }

  function getPointFromEvent(e: React.PointerEvent): Pt {
    const canvas = canvasRef.current as HTMLCanvasElement;
    const rect = canvas.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  }

  function drawLine(a: Pt, b: Pt) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }

  function onMovePoint(p: Pt) {
    // record
    pointsRef.current = [...pointsRef.current, p];

    // guided stats
    if (mode === 'guided') {
      const mask = maskRef.current;
      if (mask) {
        const st = guidedInsideRef.current;
        st.total += 1;
        const inside = alphaAtCss(mask, p.x, p.y) > 10;
        if (inside) {
          st.inside += 1;
          const cx = Math.floor(p.x / mask.cellSize);
          const cy = Math.floor(p.y / mask.cellSize);
          guidedVisitedRef.current.add(`${cx}:${cy}`);
        }
        scheduleGuidedUIUpdate();
      }
    }
  }

  async function onDone() {
    if (locked) return;
    playClick();

    const pts = pointsRef.current;

    if (mode === 'guided') {
      const mask = maskRef.current;
      if (!mask) {
        playError();
        await speakFeedback('משהו השתבש. ננסה שוב');
        return;
      }

      const visited = guidedVisitedRef.current.size;
      const coverage = visited / mask.totalLetterCells;
      const st = guidedInsideRef.current;
      const insideRatio = st.total > 0 ? st.inside / st.total : 0;

      const enough = pts.length >= 26;
      const goodCoverage = coverage >= 0.22;
      const goodInside = insideRatio >= 0.60;

      if (enough && goodCoverage && goodInside) {
        setLocked(true);
        playSuccess();
        setShowConfetti(true);

        addStars(1);
        incrementGame('trace');
        markMastery(target, 1);

        await speakFeedback('כל הכבוד! כתבת על האות יפה!');

        setTimeout(() => setShowConfetti(false), 600);
        setTimeout(() => setNewLetter(forcedTarget ?? undefined), 950);
      } else {
        playError();
        if (!enough) {
          await speakFeedback('בוא נכתוב עוד קצת על האות');
        } else if (!goodInside) {
          await speakFeedback('כמעט. נסה להישאר על האות');
        } else {
          await speakFeedback('יפה! עכשיו תעבור על כל האות עד הסוף');
        }
      }

      return;
    }

    // free mode (legacy)
    const enough = pts.length >= 40;
    if (enough) {
      setLocked(true);
      playSuccess();
      setShowConfetti(true);

      addStars(1);
      incrementGame('trace');
      markMastery(target, 1);

      await speakFeedback('כל הכבוד!');

      setTimeout(() => setShowConfetti(false), 600);
      setTimeout(() => setNewLetter(forcedTarget ?? undefined), 950);
    } else {
      playError();
      await speakFeedback('בוא ננסה עוד קצת. תכתוב על האות עם האצבע');
    }
  }

  // init
  useEffect(() => {
    setNewLetter(forcedTarget ?? undefined);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // resize canvas
  useEffect(() => {
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    return () => window.removeEventListener('resize', resizeCanvas);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // rebuild mask when target or canvas size changes
  useEffect(() => {
    if (!target) return;
    if (!canvasSpec.cssW || !canvasSpec.cssH) return;

    const mask = buildLetterMask(target, canvasSpec);
    maskRef.current = mask;
    setGuidedStartPt(mask?.startPt ?? null);

    // reset stats when mask rebuilt
    guidedVisitedRef.current = new Set();
    guidedInsideRef.current = { inside: 0, total: 0 };
    setGuidedCoverage(0);
    setGuidedInsideRatio(0);
  }, [target, canvasSpec.cssW, canvasSpec.cssH, canvasSpec.dpr]);

  const letterName = LETTERS_BY_CHAR[target]?.name ?? target;

  return (
    <div className="lesson">
      <Confetti show={showConfetti} />

      <div className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
        <div style={{ fontWeight: 900, fontSize: 18 }}>כתיבה</div>
        <button
          className="icon-btn"
          onClick={async () => {
            playClick();
            const nextMode = mode === 'guided' ? 'free' : 'guided';
            setMode(nextMode);
            clearBoard();
            if (nextMode === 'guided') {
              await speakFeedback('מצב כתיבה מודרכת');
            } else {
              await speakFeedback('מצב כתיבה חופשית');
            }
          }}
          aria-label="החלפת מצב כתיבה"
          title="החלפת מצב"
        >
          {mode === 'guided' ? '🧭' : '🖍️'}
        </button>
      </div>

      <div className="card" style={{ textAlign: 'center', fontWeight: 900, fontSize: 16 }}>
        {mode === 'guided' ? `מודרך - ${letterName}` : `חופשי - ${letterName}`}
      </div>

      {mode === 'guided' ? (
        <div className="card" style={{ display: 'flex', gap: 10, alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ fontWeight: 800 }}>התקדמות</div>
          <div style={{ flex: 1, height: 14, background: 'rgba(255,255,255,0.75)', borderRadius: 999, overflow: 'hidden', boxShadow: 'inset 0 0 0 1px rgba(17,24,39,0.08)' }}>
            <div
              style={{
                height: '100%',
                width: `${Math.round(guidedCoverage * 100)}%`,
                background: 'rgba(110,231,183,0.95)',
              }}
            />
          </div>
          <div style={{ fontWeight: 900, minWidth: 52, textAlign: 'left' }}>{Math.round(guidedCoverage * 100)}%</div>
        </div>
      ) : null}

      <div className="trace-wrap" aria-label="כתיבה על המסך">
        <div className="ghost" aria-hidden="true" style={{ color: LETTERS_BY_CHAR[target]?.color ?? 'rgba(17,24,39,0.6)' }}>
          {target}
        </div>

        {mode === 'guided' && guidedStartPt ? (
          <div
            className="start-dot"
            style={{
              left: `${Math.max(0, guidedStartPt.x)}px`,
              top: `${Math.max(0, guidedStartPt.y)}px`,
            }}
            aria-hidden="true"
          >
            <div className="dot" />
            <div className="tag">התחל</div>
          </div>
        ) : null}

        <canvas
          ref={canvasRef}
          onPointerDown={(e) => {
            if (locked) return;
            (e.target as HTMLCanvasElement).setPointerCapture(e.pointerId);
            isDownRef.current = true;
            const p = getPointFromEvent(e);
            lastRef.current = p;
            onMovePoint(p);
          }}
          onPointerMove={(e) => {
            if (locked) return;
            if (!isDownRef.current) return;
            const p = getPointFromEvent(e);
            const last = lastRef.current;
            if (last) drawLine(last, p);
            lastRef.current = p;
            onMovePoint(p);
          }}
          onPointerUp={() => {
            isDownRef.current = false;
            lastRef.current = null;
          }}
          onPointerCancel={() => {
            isDownRef.current = false;
            lastRef.current = null;
          }}
        />
      </div>

      {mode === 'guided' ? (
        <div className="card" style={{ fontSize: 14, fontWeight: 700, color: 'rgba(17,24,39,0.75)' }}>
          טיפ: תעבור על כל האות. אם יצאת מהקו - זה בסדר, פשוט תחזור.
        </div>
      ) : null}

      <div className="card" style={{ display: 'flex', gap: 10 }}>
        <button
          className="big-btn"
          onClick={() => {
            playClick();
            clearBoard();
          }}
          style={{ flex: 1, background: 'rgba(255,255,255,0.92)', height: 86 }}
          disabled={locked}
        >
          🧼 נקה
        </button>

        <button className="big-btn" onClick={onDone} style={{ flex: 1, height: 86 }}>
          ⭐ סיימתי
        </button>
      </div>

      {mode === 'guided' ? (
        <div className="card" style={{ fontSize: 12, fontWeight: 700, color: 'rgba(17,24,39,0.65)' }}>
          דיוק: {Math.round(guidedInsideRatio * 100)}%
        </div>
      ) : null}
    </div>
  );
}
