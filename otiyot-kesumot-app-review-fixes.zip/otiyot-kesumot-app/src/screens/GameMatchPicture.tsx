import React, { useEffect, useMemo, useState } from 'react';
import { LETTERS_BY_CHAR, getUnlockedLetterChars } from '../data/letters';
import { WORD_BANK } from '../data/words';
import { useApp } from '../context/AppContext';
import { Confetti } from '../components/Confetti';
import { nextFromBag } from '../lib/bag';
import { playClick, playError, playSuccess } from '../lib/audio';

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function GameMatchPicture() {
  const { progress, addStars, incrementGame, markMastery, speakInstruction, speakFeedback } = useApp();

  const availableLetters = useMemo(() => Array.from(getUnlockedLetterChars(progress.totalStars)), [progress.totalStars]);

  const pool = useMemo(() => {
    const allowed = new Set(availableLetters);
    const filtered = WORD_BANK.filter((w) => allowed.has(w.startsWith));
    return filtered.length >= 30 ? filtered : WORD_BANK;
  }, [availableLetters]);

  const [targetLetter, setTargetLetter] = useState<string>('');
  const [word, setWord] = useState<{ word: string; emoji: string; startsWith: string } | null>(null);
  const [options, setOptions] = useState<string[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [locked, setLocked] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  function newRound() {
    const picked = nextFromBag('match-picture/words', pool);
    const t = picked.startsWith;

    const letters = availableLetters.length >= 3 ? availableLetters : Array.from(new Set(pool.map((x) => x.startsWith)));
    const others = shuffle(letters.filter((c) => c !== t)).slice(0, 2);

    setWord(picked);
    setTargetLetter(t);
    setOptions(shuffle([t, ...others]));
    setSelected(null);
    setLocked(false);

    speakInstruction(`באיזו אות מתחילה המילה ${picked.word}?`);
  }

  useEffect(() => {
    newRound();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function onPick(char: string) {
    if (locked) return;
    playClick();
    setSelected(char);

    if (char === targetLetter) {
      setLocked(true);
      playSuccess();
      setShowConfetti(true);

      addStars(1);
      incrementGame('matchPicture');
      const { becameLearned } = markMastery(targetLetter, 1);

      if (becameLearned) {
        await speakFeedback(`כל הכבוד! למדת את האות ${LETTERS_BY_CHAR[targetLetter]?.name ?? targetLetter}!`);
      } else {
        await speakFeedback('מעולה!');
      }

      setTimeout(() => setShowConfetti(false), 600);
      setTimeout(() => newRound(), 950);
    } else {
      playError();
      await speakFeedback('כמעט! ננסה עוד פעם');
    }
  }

  return (
    <div className="lesson">
      <Confetti show={showConfetti} />

      <div className="card" style={{ textAlign: 'center', fontWeight: 900, fontSize: 18 }}>
        התאם לתמונה
      </div>

      <div className="picture" aria-label="תמונה">
        {word ? <div style={{ fontSize: 120, transform: 'translateY(6px)' }}>{word.emoji}</div> : null}
      </div>

      <div className="choice-grid" aria-label="בחירת אות">
        {options.map((c) => {
          const isCorrect = selected !== null && c === targetLetter;
          const isWrong = selected === c && c !== targetLetter;
          const cls = `choice${isCorrect ? ' correct' : ''}${isWrong ? ' wrong' : ''}`;
          return (
            <button key={c} className={cls} onClick={() => onPick(c)} disabled={locked}>
              {c}
            </button>
          );
        })}
      </div>
    </div>
  );
}
