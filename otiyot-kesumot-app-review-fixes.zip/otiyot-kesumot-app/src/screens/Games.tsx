import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { BigMenuButton } from '../components/BigMenuButton';
import { GameIcon } from '../components/Icons';
import { useApp } from '../context/AppContext';
import { playClick } from '../lib/audio';

export default function Games() {
  const nav = useNavigate();
  const { speakInstruction, speakFeedback } = useApp();

  useEffect(() => {
    speakInstruction('בחר משחק');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="card">
      <div className="big-grid">
        <BigMenuButton
          icon={<GameIcon size={56} />}
          title="איפה האות?"
          onClick={async () => {
            playClick();
            await speakFeedback('איפה האות?');
            nav('/games/find-letter');
          }}
          onLongPress={async () => {
            await speakFeedback('איפה האות');
          }}
        />

        <BigMenuButton
          icon={<span style={{ fontSize: 56 }}>🖼️</span>}
          title="התאם לתמונה"
          onClick={async () => {
            playClick();
            await speakFeedback('התאם לתמונה');
            nav('/games/match-picture');
          }}
          onLongPress={async () => {
            await speakFeedback('התאם לתמונה');
          }}
        />

        <BigMenuButton
          icon={<span style={{ fontSize: 56 }}>🎵</span>}
          title="חרוזים"
          onClick={async () => {
            playClick();
            await speakFeedback('חרוזים');
            nav('/games/rhymes');
          }}
          onLongPress={async () => {
            await speakFeedback('חרוזים');
          }}
        />

        <BigMenuButton
          icon={<span style={{ fontSize: 56 }}>👏</span>}
          title="הברות"
          onClick={async () => {
            playClick();
            await speakFeedback('הברות');
            nav('/games/syllables');
          }}
          onLongPress={async () => {
            await speakFeedback('משחק הברות');
          }}
        />

        <BigMenuButton
          icon={<span style={{ fontSize: 56 }}>✍️</span>}
          title="כתיבה"
          onClick={async () => {
            playClick();
            await speakFeedback('כתיבה');
            nav('/games/trace');
          }}
          onLongPress={async () => {
            await speakFeedback('כתיבה באצבע');
          }}
        />
      </div>
    </div>
  );
}
