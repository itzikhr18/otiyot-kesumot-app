import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { BigMenuButton } from '../components/BigMenuButton';
import { BookIcon, GameIcon, StarIcon } from '../components/Icons';
import { useApp } from '../context/AppContext';
import { playClick } from '../lib/audio';

export default function Home() {
  const nav = useNavigate();
  const { speakInstruction, speakFeedback } = useApp();

  useEffect(() => {
    // מסך בית - הוראה קולית
    speakInstruction('שלום! מה בא לך לעשות?');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="main">
      <div className="card">
        <div className="big-grid">
          <BigMenuButton
            icon={<BookIcon size={56} />}
            title="לימוד"
            onClick={async () => {
              playClick();
              await speakFeedback('בוא נלמד אותיות!');
              nav('/letters');
            }}
            onLongPress={async () => {
              await speakFeedback('לימוד אותיות');
            }}
          />

          <BigMenuButton
            icon={<GameIcon size={56} />}
            title="משחקים"
            onClick={async () => {
              playClick();
              await speakFeedback('בוא נשחק!');
              nav('/games');
            }}
            onLongPress={async () => {
              await speakFeedback('משחקים');
            }}
          />

          <BigMenuButton
            icon={<StarIcon size={56} />}
            title="הכוכבים שלי"
            onClick={async () => {
              playClick();
              await speakFeedback('בוא נראה כמה כוכבים יש לך!');
              nav('/stars');
            }}
            onLongPress={async () => {
              await speakFeedback('הכוכבים שלי');
            }}
          />
        </div>
      </div>
    </div>
  );
}
