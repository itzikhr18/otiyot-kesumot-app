# אודיו (נכסים)

בגרסה הזו ההוראות הקוליות משתמשות בקול של הדפדפן (SpeechSynthesis) כדי לעבוד בלי הקלטות.

כדי להתאים לאפיון (קבצי MP3 מוקלטים מראש):
- הוסיפו כאן קבצי MP3 משלכם, למשל:
  - audio/letters/א.mp3
  - audio/prompts/home_welcome.mp3
- לאחר מכן עדכנו את הקוד ב-`src/lib/audio.ts` כך שישמיע את הקבצים במקום TTS.

נכסים קיימים:
- click.wav
- success.wav
- error.wav
- placeholder_voice.wav
