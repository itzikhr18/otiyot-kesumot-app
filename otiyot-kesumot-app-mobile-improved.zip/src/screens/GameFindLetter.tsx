import React, { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ALL_LETTERS, LETTERS_BY_CHAR, getUnlockedLetterChars } from '../data/letters';
import { useApp } from '../context/AppContext';
import { Confetti } from '../components/Confetti';
import { nextFromBag } from '../lib/bag';
import { playClick, playError, playSuccess } from '../lib/audio';

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function GameFindLetter() {
  const [search] = useSearchParams();
  const forcedTarget = search.get('target') ? decodeURIComponent(search.get('target') as string) : null;

  const { progress, addStars, incrementGame, markMastery, speakInstruction, speakFeedback } = useApp();

  const unlockedChars = useMemo(() => Array.from(getUnlockedLetterChars(progress.totalStars)), [progress.totalStars]);
  const allChars = useMemo(() => ALL_LETTERS.map((l) => l.char), []);

  const available = unlockedChars.length >= 4 ? unlockedChars : allChars;

  const [target, setTarget] = useState<string>('');
  const [options, setOptions] = useState<string[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [locked, setLocked] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  function pickNextTarget(): string {
    if (forcedTarget) return forcedTarget;
    const items = available.map((c) => ({ id: c, char: c }));
    return nextFromBag('find-letter/targets', items).char;
  }

  function newRound(nextTarget?: string) {
    const t = nextTarget ?? pickNextTarget();
    const others = shuffle(available.filter((c) => c !== t)).slice(0, 3);
    setTarget(t);
    setOptions(shuffle([t, ...others]));
    setSelected(null);
    setLocked(false);

    const name = LETTERS_BY_CHAR[t]?.name ?? t;
    speakInstruction(`איפה האות ${name}?`);
  }

  useEffect(() => {
    newRound(forcedTarget ?? undefined);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function onPick(char: string) {
    if (locked) return;
    playClick();
    setSelected(char);

    if (char === target) {
      setLocked(true);
      playSuccess();
      setShowConfetti(true);

      addStars(1);
      incrementGame('findLetter');
      const { becameLearned } = markMastery(target, 1);

      if (becameLearned) {
        await speakFeedback(`כל הכבוד! למדת את האות ${LETTERS_BY_CHAR[target]?.name ?? target}!`);
      } else {
        await speakFeedback('כל הכבוד!');
      }

      setTimeout(() => setShowConfetti(false), 600);
      setTimeout(() => newRound(forcedTarget ?? undefined), 950);
    } else {
      playError();
      await speakFeedback('כמעט! ננסה עוד פעם');
    }
  }

  return (
    <div className="lesson">
      <Confetti show={showConfetti} />

      <div className="card" style={{ textAlign: 'center', fontWeight: 900, fontSize: 18 }}>
        איפה האות?
      </div>

      <div className="choice-grid" aria-label="בחירת אות">
        {options.map((c) => {
          const isCorrect = selected !== null && c === target;
          const isWrong = selected === c && c !== target;
          const cls = `choice${isCorrect ? ' correct' : ''}${isWrong ? ' wrong' : ''}`;
          return (
            <button key={c} className={cls} onClick={() => onPick(c)} disabled={locked}>
              {c}
            </button>
          );
        })}
      </div>
    </div>
  );
}
