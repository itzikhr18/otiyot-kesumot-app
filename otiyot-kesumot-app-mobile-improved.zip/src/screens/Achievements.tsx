import React, { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { ALL_LETTERS } from '../data/letters';

export default function Achievements() {
  const { progress, speakInstruction } = useApp();

  useEffect(() => {
    speakInstruction('אלה הכוכבים שלך');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const learned = new Set(progress.learnedLetters);

  return (
    <div className="lesson">
      <div className="card" style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 46, fontWeight: 900 }}>⭐ {progress.totalStars}</div>
        <div style={{ marginTop: 6, fontWeight: 800, color: 'rgba(17,24,39,0.75)' }}>כוכבים</div>
      </div>

      <div className="card">
        <div style={{ fontWeight: 900, marginBottom: 10 }}>אותיות שנלמדו</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
          {ALL_LETTERS.map((l) => (
            <div
              key={l.char}
              style={{
                padding: '10px 14px',
                borderRadius: 999,
                background: learned.has(l.char) ? 'var(--success)' : 'rgba(255,255,255,0.75)',
                border: `3px solid ${l.color}`,
                fontWeight: 900,
                fontSize: 22,
                minWidth: 44,
                textAlign: 'center',
              }}
            >
              {l.char}
            </div>
          ))}
        </div>
      </div>

      <div className="card" style={{ fontWeight: 800, color: 'rgba(17,24,39,0.75)' }}>
        טיפ להורים: כדי לאפס את ההתקדמות, מחקו את נתוני האתר בדפדפן.
      </div>
    </div>
  );
}
