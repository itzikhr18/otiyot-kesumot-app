import React, { useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { LETTERS_BY_CHAR } from '../data/letters';
import { BigMenuButton } from '../components/BigMenuButton';
import { useApp } from '../context/AppContext';
import { playClick } from '../lib/audio';

function isEmojiPicture(p: string): boolean {
  return p.startsWith('emoji:');
}

function emojiFromPicture(p: string): string {
  return p.replace(/^emoji:/, '');
}

export default function LetterLesson() {
  const nav = useNavigate();
  const { char } = useParams();
  const decoded = decodeURIComponent(char ?? '');
  const letter = LETTERS_BY_CHAR[decoded];
  const base = import.meta.env.BASE_URL;
  const { speakInstruction, speakFeedback } = useApp();

  useEffect(() => {
    if (!letter) return;
    const text = `זו האות ${letter.name}. כמו ${letter.exampleWord}.`;
    speakInstruction(text);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [decoded]);

  if (!letter) {
    return <div className="card">אופס! האות לא נמצאה.</div>;
  }

  const picture = letter.picture ?? '';
  const emoji = isEmojiPicture(picture) ? emojiFromPicture(picture) : null;

  return (
    <div className="lesson">
      <button
        className="big-letter"
        aria-label="השמעה חוזרת"
        onClick={async () => {
          playClick();
          await speakInstruction(`זו האות ${letter.name}`);
        }}
      >
        <div className="char" style={{ color: letter.color }}>
          {letter.char}
        </div>
      </button>

      <button
        className="picture"
        aria-label="השמעת מילת הדוגמה"
        onClick={async () => {
          playClick();
          await speakFeedback(`כמו במילה ${letter.exampleWord}`);
        }}
      >
        {emoji ? (
          <div style={{ fontSize: 120, transform: 'translateY(6px)' }}>{emoji}</div>
        ) : (
          <img src={`${base}${picture}`} alt="" />
        )}
      </button>

      <div className="card">
        <div className="big-grid">
          <BigMenuButton
            icon={<span style={{ fontSize: 56 }}>🎮</span>}
            title="משחק"
            onClick={async () => {
              playClick();
              await speakFeedback('עכשיו בוא נשחק עם האות!');
              nav(`/games/find-letter?target=${encodeURIComponent(letter.char)}`);
            }}
            onLongPress={async () => {
              await speakFeedback('משחק קצר');
            }}
          />

          <BigMenuButton
            icon={<span style={{ fontSize: 56 }}>✍️</span>}
            title="כתיבה"
            onClick={async () => {
              playClick();
              await speakFeedback('בוא נכתוב את האות באצבע');
              nav(`/games/trace?target=${encodeURIComponent(letter.char)}`);
            }}
            onLongPress={async () => {
              await speakFeedback('כתיבה מודרכת');
            }}
          />
        </div>
      </div>
    </div>
  );
}
