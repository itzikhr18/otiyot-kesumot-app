import React, { useEffect, useMemo, useState } from 'react';
import { WORD_BANK, type WordCard } from '../data/words';
import { useApp } from '../context/AppContext';
import { Confetti } from '../components/Confetti';
import { nextFromBag } from '../lib/bag';
import { playClick, playError, playSuccess } from '../lib/audio';

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function GameSyllables() {
  const { addStars, incrementGame, speakInstruction, speakFeedback } = useApp();

  const pool = useMemo(() => WORD_BANK.filter((w) => typeof w.syllables === 'number' && (w.syllables as number) >= 1 && (w.syllables as number) <= 4), []);

  const [word, setWord] = useState<WordCard | null>(null);
  const [options, setOptions] = useState<number[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [locked, setLocked] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  function newRound() {
    if (pool.length === 0) return;
    const w = nextFromBag('syllables/words', pool);

    const correct = w.syllables as number;
    const baseOpts = [1, 2, 3, 4];
    const opts = shuffle(baseOpts).slice(0, 3);
    if (!opts.includes(correct)) {
      opts[Math.floor(Math.random() * opts.length)] = correct;
    }

    setWord(w);
    setOptions(shuffle(opts));
    setSelected(null);
    setLocked(false);

    speakInstruction(`כמה הברות יש במילה ${w.word}?`);
  }

  useEffect(() => {
    newRound();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function onPick(n: number) {
    if (locked || !word) return;
    playClick();
    setSelected(n);

    const correct = word.syllables as number;
    if (n === correct) {
      setLocked(true);
      playSuccess();
      setShowConfetti(true);

      addStars(1);
      incrementGame('syllables');

      await speakFeedback('מעולה!');

      setTimeout(() => setShowConfetti(false), 600);
      setTimeout(() => newRound(), 950);
    } else {
      playError();
      await speakFeedback('כמעט! ננסה עוד פעם');
    }
  }

  function claps(n: number): string {
    return '👏'.repeat(n);
  }

  return (
    <div className="lesson">
      <Confetti show={showConfetti} />

      <div className="card" style={{ textAlign: 'center', fontWeight: 900, fontSize: 18 }}>
        הברות
      </div>

      <div className="picture" aria-label="המילה שנשמעת">
        {word ? <div style={{ fontSize: 120, transform: 'translateY(6px)' }}>{word.emoji}</div> : null}
      </div>

      <div className="choice-grid" aria-label="בחירה">
        {options.map((n) => {
          const isCorrect = selected !== null && word && n === (word.syllables as number);
          const isWrong = selected === n && word && n !== (word.syllables as number);
          const cls = `choice${isCorrect ? ' correct' : ''}${isWrong ? ' wrong' : ''}`;
          return (
            <button key={n} className={cls} onClick={() => onPick(n)} disabled={locked} style={{ fontSize: 34, letterSpacing: 2 }}>
              {claps(n)}
            </button>
          );
        })}
      </div>
    </div>
  );
}
