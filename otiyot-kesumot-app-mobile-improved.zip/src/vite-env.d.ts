// Minimal Vite env typings (works גם בלי תלות ב-vite/client)
interface ImportMetaEnv {
  readonly BASE_URL: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
