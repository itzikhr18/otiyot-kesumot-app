import React, { useEffect, useMemo } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';

import { TopBar } from './components/TopBar';
import { BottomBar } from './components/BottomBar';
import { warmUpVoices } from './lib/audio';
import { useApp } from './context/AppContext';

import Home from './screens/Home';
import Intro from './screens/Intro';
import Letters from './screens/Letters';
import LetterLesson from './screens/LetterLesson';
import Games from './screens/Games';
import GameFindLetter from './screens/GameFindLetter';
import GameMatchPicture from './screens/GameMatchPicture';
import GameRhymes from './screens/GameRhymes';
import GameSyllables from './screens/GameSyllables';
import GameTrace from './screens/GameTrace';
import Achievements from './screens/Achievements';

function HomeGate() {
  const { progress } = useApp();
  if (!progress.hasSeenIntro) return <Navigate to="/intro" replace />;
  return <Home />;
}

function useMood(): 'neutral' | 'think' | 'celebrate' {
  const loc = useLocation();
  if (loc.pathname.startsWith('/games')) return 'think';
  if (loc.pathname.startsWith('/stars')) return 'celebrate';
  return 'neutral';
}

function useBackgroundKey(): string {
  const loc = useLocation();
  const p = loc.pathname;

  if (p.startsWith('/intro')) return 'intro';
  if (p === '/') return 'home';
  if (p.startsWith('/letters/')) return 'lesson';
  if (p.startsWith('/letters')) return 'letters';

  if (p === '/games') return 'games';
  if (p.startsWith('/games/find-letter')) return 'find';
  if (p.startsWith('/games/match-picture')) return 'match';
  if (p.startsWith('/games/rhymes')) return 'rhymes';
  if (p.startsWith('/games/syllables')) return 'syllables';
  if (p.startsWith('/games/trace')) return 'trace';

  if (p.startsWith('/stars')) return 'stars';

  return 'home';
}

export default function App() {
  const loc = useLocation();
  const mood = useMood();
  const bgKey = useBackgroundKey();
  const base = import.meta.env.BASE_URL;

  useEffect(() => {
    warmUpVoices();
  }, []);

  const bgStyle = useMemo(() => {
    const url = `url('${base}assets/backgrounds/bg-${bgKey}.webp')`;
    return { ['--bg-image' as any]: url } as React.CSSProperties;
  }, [base, bgKey]);

  return (
    <div className="app-shell" style={bgStyle}>
      <div className="safe-area">
        <TopBar />

        <div className="main">
          <div className="screen-anim" key={loc.pathname}>
            <Routes location={loc}>
              <Route path="/intro" element={<Intro />} />
              <Route path="/" element={<HomeGate />} />
              <Route path="/letters" element={<Letters />} />
              <Route path="/letters/:char" element={<LetterLesson />} />

              <Route path="/games" element={<Games />} />
              <Route path="/games/find-letter" element={<GameFindLetter />} />
              <Route path="/games/match-picture" element={<GameMatchPicture />} />
              <Route path="/games/rhymes" element={<GameRhymes />} />
              <Route path="/games/syllables" element={<GameSyllables />} />
              <Route path="/games/trace" element={<GameTrace />} />

              <Route path="/stars" element={<Achievements />} />

              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
        </div>

        <BottomBar mood={mood} />
      </div>
    </div>
  );
}
