import React from 'react';

export function BigMenuButton({
  icon,
  title,
  onClick,
  onLongPress,
  showText = false,
}: {
  icon: React.ReactNode;
  title: string;
  onClick: () => void | Promise<void>;
  onLongPress?: () => void | Promise<void>;
  showText?: boolean;
}) {
  const timerRef = React.useRef<number | null>(null);
  const longFiredRef = React.useRef(false);

  function clearTimer() {
    if (timerRef.current !== null) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  }

  function startTimer() {
    if (!onLongPress) return;
    clearTimer();
    longFiredRef.current = false;
    timerRef.current = window.setTimeout(() => {
      longFiredRef.current = true;
      void onLongPress();
    }, 450);
  }

  return (
    <button
      className="big-btn"
      aria-label={title}
      onPointerDown={() => startTimer()}
      onPointerUp={() => clearTimer()}
      onPointerCancel={() => clearTimer()}
      onPointerLeave={() => clearTimer()}
      onClick={async () => {
        // אחרי לחיצה ארוכה, הדפדפן עדיין יכול לירות click - מתעלמים
        if (longFiredRef.current) {
          longFiredRef.current = false;
          return;
        }
        await onClick();
      }}
    >
      {icon}
      {showText ? (
        <div className="text">
          <div className="label">{title}</div>
        </div>
      ) : null}
    </button>
  );
}
