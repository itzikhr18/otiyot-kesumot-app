import React from 'react';

export function LetterCard({
  char,
  learned,
  locked = false,
  color,
  onClick,
}: {
  char: string;
  learned: boolean;
  locked?: boolean;
  color: string;
  onClick: () => void | Promise<void>;
}) {
  return (
    <button
      className={`letter-card${locked ? ' locked' : ''}`}
      onClick={onClick}
      style={{ border: `4px solid ${color}` }}
      aria-label={`אות ${char}`}
    >
      {learned ? <div className="badge">⭐</div> : null}
      {locked ? <div className="lock" aria-hidden="true">🔒</div> : null}
      <div className="char" style={{ color }}>
        {char}
      </div>
    </button>
  );
}
