import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { loadProgress, saveProgress, type ProgressState } from '../lib/storage';
import { speak } from '../lib/audio';

type AppContextValue = {
  progress: ProgressState;
  lastInstruction: string | null;
  addStars: (n?: number) => void;
  markMastery: (letterChar: string, n?: number) => { becameLearned: boolean };
  incrementGame: (game: 'findLetter' | 'matchPicture' | 'rhymes' | 'syllables' | 'trace') => void;
  speakInstruction: (text: string) => Promise<void>;
  speakFeedback: (text: string) => Promise<void>;
  repeatInstruction: () => Promise<void>;
  setHasSeenIntro: () => void;
  resetAll: () => void;
};

const Ctx = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [progress, setProgress] = useState<ProgressState>(() => loadProgress());
  const [lastInstruction, setLastInstruction] = useState<string | null>(null);

  useEffect(() => {
    saveProgress(progress);
  }, [progress]);

  const api = useMemo<AppContextValue>(() => {
    function touchActivity() {
      setProgress((p) => ({ ...p, lastActivity: new Date().toISOString() }));
    }

    function addStars(n = 1) {
      setProgress((p) => ({ ...p, totalStars: p.totalStars + n, lastActivity: new Date().toISOString() }));
    }

    function markMastery(letterChar: string, n = 1) {
      const current = progress.letterMastery[letterChar] ?? 0;
      const next = current + n;
      const alreadyLearned = progress.learnedLetters.includes(letterChar);
      const shouldLearn = !alreadyLearned && next >= 3;

      setProgress((p) => {
        const current2 = p.letterMastery[letterChar] ?? 0;
        const next2 = current2 + n;
        const alreadyLearned2 = p.learnedLetters.includes(letterChar);
        const shouldLearn2 = !alreadyLearned2 && next2 >= 3;

        return {
          ...p,
          letterMastery: { ...p.letterMastery, [letterChar]: next2 },
          learnedLetters: shouldLearn2 ? [...p.learnedLetters, letterChar] : p.learnedLetters,
          lastActivity: new Date().toISOString(),
        };
      });

      return { becameLearned: shouldLearn };
    }

    function incrementGame(game: 'findLetter' | 'matchPicture' | 'rhymes' | 'syllables' | 'trace') {
      setProgress((p) => ({
        ...p,
        gamesCompleted: { ...p.gamesCompleted, [game]: p.gamesCompleted[game] + 1 },
        lastActivity: new Date().toISOString(),
      }));
    }

    async function speakInstruction(text: string) {
      setLastInstruction(text);
      await speak(text);
      touchActivity();
    }

    async function speakFeedback(text: string) {
      await speak(text);
      touchActivity();
    }

    async function repeatInstruction() {
      if (!lastInstruction) return;
      await speak(lastInstruction);
      touchActivity();
    }

    function setHasSeenIntro() {
      setProgress((p) => ({ ...p, hasSeenIntro: true, lastActivity: new Date().toISOString() }));
    }

    function resetAll() {
      localStorage.removeItem('otiyot-kesumot/v1');
      setProgress(loadProgress());
      setLastInstruction(null);
    }

    return {
      progress,
      lastInstruction,
      addStars,
      markMastery,
      incrementGame,
      speakInstruction,
      speakFeedback,
      repeatInstruction,
      setHasSeenIntro,
      resetAll,
    };
  }, [progress, lastInstruction]);

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}

export function useApp() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useApp must be used inside AppProvider');
  return v;
}
