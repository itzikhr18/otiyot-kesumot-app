function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const BAG_PREFIX = 'otiyot-kesumot/bag/v1/';

type BagState = {
  remainingIds: string[];
};

/**
 * בחירה אקראית בלי חזרות תכופות:
 * - שומר "שקית" של מזהים ב-localStorage
 * - כל פעם שולף מזהה אחד
 * - כשנגמר, מערבב מחדש
 */
export function nextFromBag<T extends { id: string }>(bagKey: string, items: T[]): T {
  const key = `${BAG_PREFIX}${bagKey}`;
  const byId = new Map(items.map((x) => [x.id, x]));

  function fresh(): BagState {
    return { remainingIds: shuffle(items.map((x) => x.id)) };
  }

  let state: BagState | null = null;
  try {
    const raw = localStorage.getItem(key);
    if (raw) state = JSON.parse(raw) as BagState;
  } catch {
    state = null;
  }

  if (!state || !Array.isArray(state.remainingIds) || state.remainingIds.length === 0) {
    state = fresh();
  }

  // מוציאים מזהה ראשון שקיים עדיין במאגר
  while (state.remainingIds.length > 0) {
    const id = state.remainingIds.shift() as string;
    const item = byId.get(id);
    if (item) {
      try {
        localStorage.setItem(key, JSON.stringify(state));
      } catch {
        // ignore
      }
      return item;
    }
  }

  // fallback
  state = fresh();
  const id = state.remainingIds.shift() as string;
  const item = byId.get(id) ?? items[0];
  try {
    localStorage.setItem(key, JSON.stringify(state));
  } catch {
    // ignore
  }
  return item;
}

export function clearBag(bagKey: string) {
  const key = `${BAG_PREFIX}${bagKey}`;
  try {
    localStorage.removeItem(key);
  } catch {
    // ignore
  }
}
