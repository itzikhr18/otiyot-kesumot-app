type SpeakOptions = {
  rate?: number;
  pitch?: number;
  volume?: number;
};

function getHebrewVoice(): SpeechSynthesisVoice | null {
  const voices = window.speechSynthesis.getVoices();
  const he = voices.find((v) => v.lang?.toLowerCase().startsWith('he'));
  return he ?? null;
}

export function speak(text: string, options: SpeakOptions = {}): Promise<void> {
  return new Promise((resolve) => {
    if (!('speechSynthesis' in window)) {
      resolve();
      return;
    }

    const utter = new SpeechSynthesisUtterance(text);
    const voice = getHebrewVoice();
    if (voice) utter.voice = voice;

    utter.lang = voice?.lang ?? 'he-IL';
    utter.rate = options.rate ?? 0.95;
    utter.pitch = options.pitch ?? 1.02;
    utter.volume = options.volume ?? 1.0;

    utter.onend = () => resolve();
    utter.onerror = () => resolve();

    // עצירה כדי למנוע הצטברות משפטים
    try {
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utter);
    } catch {
      resolve();
    }
  });
}

function tone(freq: number, durationMs: number, type: OscillatorType = 'sine', gainValue = 0.05) {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.value = freq;
    g.gain.value = gainValue;
    o.connect(g);
    g.connect(ctx.destination);
    o.start();
    setTimeout(() => {
      o.stop();
      ctx.close().catch(() => undefined);
    }, durationMs);
  } catch {
    // אין אודיו - מתעלמים
  }
}

export function playClick() {
  tone(520, 60, 'square', 0.03);
}

export function playSuccess() {
  tone(880, 110, 'sine', 0.05);
  setTimeout(() => tone(1320, 130, 'sine', 0.045), 110);
}

export function playError() {
  tone(220, 160, 'sawtooth', 0.03);
}

export function warmUpVoices() {
  // ב-Chrome לעתים צריך "לגעת" במערכת כדי לקבל קולות זמינים
  try {
    window.speechSynthesis.getVoices();
  } catch {
    // no-op
  }
}
