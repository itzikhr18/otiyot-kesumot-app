export interface GamesCompleted {
  findLetter: number;
  matchPicture: number;
  rhymes: number;
  syllables: number;
  trace: number;
}

export interface ProgressState {
  learnedLetters: string[];
  totalStars: number;
  gamesCompleted: GamesCompleted;
  lastActivity: string; // ISO
  letterMastery: Record<string, number>; // מספר הצלחות לכל אות
  hasSeenIntro: boolean;
}

const STORAGE_KEY = 'otiyot-kesumot/v1';

export function defaultProgress(): ProgressState {
  return {
    learnedLetters: [],
    totalStars: 0,
    gamesCompleted: { findLetter: 0, matchPicture: 0, rhymes: 0, syllables: 0, trace: 0 },
    lastActivity: new Date().toISOString(),
    letterMastery: {},
    hasSeenIntro: false,
  };
}

export function loadProgress(): ProgressState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultProgress();
    const parsed = JSON.parse(raw) as Partial<ProgressState> | null;
    if (!parsed || typeof parsed !== 'object') return defaultProgress();

    const base = defaultProgress();
    return {
      learnedLetters: Array.isArray(parsed.learnedLetters) ? parsed.learnedLetters : base.learnedLetters,
      totalStars: typeof parsed.totalStars === 'number' ? parsed.totalStars : base.totalStars,
      gamesCompleted: {
        findLetter: typeof parsed.gamesCompleted?.findLetter === 'number' ? parsed.gamesCompleted.findLetter : base.gamesCompleted.findLetter,
        matchPicture: typeof parsed.gamesCompleted?.matchPicture === 'number' ? parsed.gamesCompleted.matchPicture : base.gamesCompleted.matchPicture,
        rhymes: typeof (parsed as any).gamesCompleted?.rhymes === 'number' ? (parsed as any).gamesCompleted.rhymes : base.gamesCompleted.rhymes,
        syllables: typeof (parsed as any).gamesCompleted?.syllables === 'number' ? (parsed as any).gamesCompleted.syllables : base.gamesCompleted.syllables,
        trace: typeof (parsed as any).gamesCompleted?.trace === 'number' ? (parsed as any).gamesCompleted.trace : base.gamesCompleted.trace,
      },
      lastActivity: typeof parsed.lastActivity === 'string' ? parsed.lastActivity : base.lastActivity,
      letterMastery: parsed.letterMastery && typeof parsed.letterMastery === 'object'
        ? (parsed.letterMastery as Record<string, number>)
        : base.letterMastery,
      hasSeenIntro: typeof (parsed as any).hasSeenIntro === 'boolean' ? (parsed as any).hasSeenIntro : base.hasSeenIntro,
    };
  } catch {
    return defaultProgress();
  }
}

export function saveProgress(state: ProgressState) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // localStorage יכול להיכשל במצב גלישה פרטי - במקרה כזה פשוט לא שומרים
  }
}
