import React, { useEffect, useMemo, useState } from 'react';
import { WORD_BANK, getRhymeKey, type WordCard } from '../data/words';
import { useApp } from '../context/AppContext';
import { Confetti } from '../components/Confetti';
import { nextFromBag } from '../lib/bag';
import { playClick, playError, playSuccess } from '../lib/audio';

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

type RhymeGroup = { id: string; key: string; words: WordCard[] };

export default function GameRhymes() {
  const { addStars, incrementGame, speakInstruction, speakFeedback } = useApp();

  const groups = useMemo<RhymeGroup[]>(() => {
    const m = new Map<string, WordCard[]>();
    for (const w of WORD_BANK) {
      const key = getRhymeKey(w.word);
      if (!key || key.length < 2) continue;
      const list = m.get(key) ?? [];
      list.push(w);
      m.set(key, list);
    }
    const out: RhymeGroup[] = [];
    for (const [key, ws] of m.entries()) {
      if (ws.length >= 3) {
        out.push({ id: key, key, words: ws });
      }
    }
    return out;
  }, []);

  const [prompt, setPrompt] = useState<WordCard | null>(null);
  const [correct, setCorrect] = useState<WordCard | null>(null);
  const [choices, setChoices] = useState<WordCard[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [locked, setLocked] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  function newRound() {
    if (groups.length === 0) return;

    const g = nextFromBag('rhymes/groups', groups);
    const ws = shuffle(g.words);
    const p = ws[0];
    const c = ws[1];

    const otherGroups = groups.filter((x) => x.key !== g.key);
    const distractors: WordCard[] = [];
    while (distractors.length < 2 && otherGroups.length > 0) {
      const og = otherGroups[Math.floor(Math.random() * otherGroups.length)];
      const w = og.words[Math.floor(Math.random() * og.words.length)];
      if (w.id !== p.id && w.id !== c.id && !distractors.some((d) => d.id === w.id)) distractors.push(w);
    }

    setPrompt(p);
    setCorrect(c);
    setChoices(shuffle([c, ...distractors]));
    setSelectedId(null);
    setLocked(false);

    speakInstruction(`מה מתחרז עם ${p.word}?`);
  }

  useEffect(() => {
    newRound();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function onPick(w: WordCard) {
    if (locked) return;
    playClick();
    setSelectedId(w.id);

    if (correct && w.id === correct.id) {
      setLocked(true);
      playSuccess();
      setShowConfetti(true);

      addStars(1);
      incrementGame('rhymes');

      await speakFeedback('יאי! זה מתחרז!');

      setTimeout(() => setShowConfetti(false), 600);
      setTimeout(() => newRound(), 950);
    } else {
      playError();
      await speakFeedback('כמעט! ננסה עוד פעם');
    }
  }

  return (
    <div className="lesson">
      <Confetti show={showConfetti} />

      <div className="card" style={{ textAlign: 'center', fontWeight: 900, fontSize: 18 }}>
        חרוזים
      </div>

      <div className="picture" aria-label="המילה שנשמעת">
        {prompt ? <div style={{ fontSize: 120, transform: 'translateY(6px)' }}>{prompt.emoji}</div> : null}
      </div>

      <div className="choice-grid" aria-label="בחירה">
        {choices.map((w) => {
          const isCorrect = selectedId !== null && correct && w.id === correct.id;
          const isWrong = selectedId === w.id && correct && w.id !== correct.id;
          const cls = `choice${isCorrect ? ' correct' : ''}${isWrong ? ' wrong' : ''}`;
          return (
            <button key={w.id} className={cls} onClick={() => onPick(w)} disabled={locked} style={{ fontSize: 54 }}>
              <span aria-hidden="true">{w.emoji}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
