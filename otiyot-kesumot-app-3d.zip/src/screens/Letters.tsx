import React, { useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { ALL_LETTERS, getUnlockedLetterChars } from '../data/letters';
import { LetterCard } from '../components/LetterCard';
import { useApp } from '../context/AppContext';
import { playClick } from '../lib/audio';

export default function Letters() {
  const nav = useNavigate();
  const { progress, speakInstruction, speakFeedback } = useApp();

  useEffect(() => {
    speakInstruction('בחר אות');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const learned = new Set(progress.learnedLetters);
  const unlocked = useMemo(() => getUnlockedLetterChars(progress.totalStars), [progress.totalStars]);

  return (
    <div className="card">
      <div className="letter-grid">
        {ALL_LETTERS.map((l) => (
          <LetterCard
            key={l.char}
            char={l.char}
            color={l.color}
            learned={learned.has(l.char)}
            locked={!unlocked.has(l.char)}
            onClick={async () => {
              playClick();
              if (!unlocked.has(l.char)) {
                await speakFeedback('האות הזו תיפתח אחרי עוד קצת כוכבים');
                return;
              }
              await speakFeedback(`בחרת ${l.name}`);
              nav(`/letters/${encodeURIComponent(l.char)}`);
            }}
          />
        ))}
      </div>
    </div>
  );
}
