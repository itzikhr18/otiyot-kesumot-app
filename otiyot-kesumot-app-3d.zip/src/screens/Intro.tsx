import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { playClick } from '../lib/audio';

export default function Intro() {
  const nav = useNavigate();
  const base = import.meta.env.BASE_URL;
  const { speakInstruction, speakFeedback, setHasSeenIntro } = useApp();

  useEffect(() => {
    speakInstruction('שלום! אני אותי הינשוף. אני אלמד אותך אותיות. לחץ על הכוכב כדי להתחיל.');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="lesson">
      <div className="card" style={{ display: 'grid', placeItems: 'center' }}>
        <img
          src={`${base}assets/owl/happy.svg`}
          alt=""
          style={{ width: 170, height: 170 }}
        />
      </div>

      <button
        className="big-btn"
        style={{ height: 140, width: '100%' }}
        aria-label="התחל"
        onClick={async () => {
          playClick();
          setHasSeenIntro();
          await speakFeedback('יאללה מתחילים!');
          nav('/');
        }}
      >
        <span style={{ fontSize: 80 }} aria-hidden="true">⭐</span>
      </button>
    </div>
  );
}
