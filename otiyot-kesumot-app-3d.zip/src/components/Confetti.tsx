import React from 'react';

export function Confetti({ show }: { show: boolean }) {
  if (!show) return null;
  const emojis = ['⭐', '🎉', '✨', '🌟'];
  const pick = emojis[Math.floor(Math.random() * emojis.length)];
  return (
    <div className="overlay" aria-hidden="true">
      <div className="confetti">{pick}</div>
    </div>
  );
}
