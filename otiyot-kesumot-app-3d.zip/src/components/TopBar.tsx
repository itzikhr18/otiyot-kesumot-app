import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { BackIcon, HomeIcon } from './Icons';
import { playClick } from '../lib/audio';

export function TopBar() {
  const nav = useNavigate();
  const loc = useLocation();

  const isHome = loc.pathname === '/';
  const isIntro = loc.pathname === '/intro';

  return (
    <div className="topbar">
      <div className="left">
        {!isHome && !isIntro && (
          <button
            className="icon-btn"
            aria-label="חזור"
            onClick={() => {
              playClick();
              nav(-1);
            }}
          >
            <BackIcon />
          </button>
        )}
      </div>

      <div className="right">
        <button
          className="icon-btn"
          aria-label="בית"
          onClick={() => {
            playClick();
            nav('/');
          }}
        >
          <HomeIcon />
        </button>
      </div>
    </div>
  );
}
