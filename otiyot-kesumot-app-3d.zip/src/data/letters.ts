export type LetterChar = string;

export interface LetterData {
  char: LetterChar;
  name: string;       // שם האות
  soundHint: string;  // רמז לצליל (לא ניקוד מלא)
  exampleWord: string;
  picture: string;    // נתיב ל-SVG או "emoji:🦁"
  color: string;      // צבע תצוגה לאות
  group: number;      // קבוצת לימוד (1-5)
}

export type LetterGroup = {
  group: number;
  title: string;
  unlockAtStars: number;
  letters: LetterChar[];
};

export const LETTER_GROUPS: LetterGroup[] = [
  { group: 1, title: 'פשוטות', unlockAtStars: 0, letters: ['ו', 'י', 'ל', 'ן'] },
  { group: 2, title: 'בסיסיות', unlockAtStars: 0, letters: ['א', 'ה', 'ח', 'ת'] },

  { group: 3, title: 'משולבות', unlockAtStars: 0, letters: ['ב', 'כ', 'מ', 'ר'] },
  { group: 4, title: 'מורכבות', unlockAtStars: 0, letters: ['ד', 'ג', 'נ', 'ע', 'פ', 'צ', 'ק', 'ש'] },
  { group: 5, title: 'מתקדמות', unlockAtStars: 0, letters: ['ז', 'ס', 'ט', 'ם', 'ף', 'ץ', 'ך'] },
];

export const ALL_LETTERS: LetterData[] = [
  // קבוצה 1
  { char: 'ו', name: 'וו', soundHint: 'ו', exampleWord: 'ורד', picture: 'assets/pictures/rose.svg', color: '#7C3AED', group: 1 },
  { char: 'י', name: 'יוד', soundHint: 'י', exampleWord: 'ילד', picture: 'assets/pictures/boy.svg', color: '#2563EB', group: 1 },
  { char: 'ל', name: 'למד', soundHint: 'ל', exampleWord: 'לב', picture: 'assets/pictures/heart.svg', color: '#DC2626', group: 1 },
  { char: 'ן', name: 'נון סופית', soundHint: 'ן', exampleWord: 'בלון', picture: 'assets/pictures/balloon.svg', color: '#0EA5E9', group: 1 },

  // קבוצה 2
  { char: 'א', name: 'אלף', soundHint: 'א', exampleWord: 'אריה', picture: 'assets/pictures/lion.svg', color: '#F59E0B', group: 2 },
  { char: 'ה', name: 'הא', soundHint: 'ה', exampleWord: 'הר', picture: 'assets/pictures/mountain.svg', color: '#059669', group: 2 },
  { char: 'ח', name: 'חית', soundHint: 'ח', exampleWord: 'חתול', picture: 'assets/pictures/cat.svg', color: '#111827', group: 2 },
  { char: 'ת', name: 'תו', soundHint: 'ת', exampleWord: 'תפוח', picture: 'assets/pictures/apple.svg', color: '#BE185D', group: 2 },

  // קבוצה 3
  { char: 'ב', name: 'בית', soundHint: 'ב', exampleWord: 'בית', picture: 'assets/pictures/house.svg', color: '#0F766E', group: 3 },
  { char: 'כ', name: 'כף', soundHint: 'כ', exampleWord: 'כדור', picture: 'assets/pictures/ball.svg', color: '#9333EA', group: 3 },
  { char: 'מ', name: 'מם', soundHint: 'מ', exampleWord: 'מים', picture: 'emoji:💧', color: '#1D4ED8', group: 3 },
  { char: 'ר', name: 'ריש', soundHint: 'ר', exampleWord: 'רכבת', picture: 'emoji:🚆', color: '#B45309', group: 3 },

  // קבוצה 4
  { char: 'ד', name: 'דלת', soundHint: 'ד', exampleWord: 'דג', picture: 'emoji:🐟', color: '#0EA5E9', group: 4 },
  { char: 'ג', name: 'גימל', soundHint: 'ג', exampleWord: 'גמל', picture: 'emoji:🐪', color: '#16A34A', group: 4 },
  { char: 'נ', name: 'נון', soundHint: 'נ', exampleWord: 'נר', picture: 'emoji:🕯️', color: '#F97316', group: 4 },
  { char: 'ע', name: 'עין', soundHint: 'ע', exampleWord: 'עוגה', picture: 'emoji:🎂', color: '#A855F7', group: 4 },
  { char: 'פ', name: 'פה', soundHint: 'פ', exampleWord: 'פרח', picture: 'emoji:🌸', color: '#DB2777', group: 4 },
  { char: 'צ', name: 'צדיק', soundHint: 'צ', exampleWord: 'צב', picture: 'emoji:🐢', color: '#059669', group: 4 },
  { char: 'ק', name: 'קוף', soundHint: 'ק', exampleWord: 'קוף', picture: 'emoji:🐵', color: '#2563EB', group: 4 },
  { char: 'ש', name: 'שין', soundHint: 'ש', exampleWord: 'שמש', picture: 'emoji:☀️', color: '#E11D48', group: 4 },

  // קבוצה 5
  { char: 'ז', name: 'זין', soundHint: 'ז', exampleWord: 'זברה', picture: 'emoji:🦓', color: '#7C3AED', group: 5 },
  { char: 'ס', name: 'סמך', soundHint: 'ס', exampleWord: 'סוס', picture: 'emoji:🐴', color: '#0F766E', group: 5 },
  { char: 'ט', name: 'טית', soundHint: 'ט', exampleWord: 'טלפון', picture: 'emoji:📱', color: '#B91C1C', group: 5 },

  { char: 'ם', name: 'מם סופית', soundHint: 'ם', exampleWord: 'ים', picture: 'emoji:🌊', color: '#0284C7', group: 5 },
  { char: 'ף', name: 'פה סופית', soundHint: 'ף', exampleWord: 'אף', picture: 'emoji:👃', color: '#EA580C', group: 5 },
  { char: 'ץ', name: 'צדיק סופית', soundHint: 'ץ', exampleWord: 'עץ', picture: 'emoji:🌳', color: '#16A34A', group: 5 },
  { char: 'ך', name: 'כף סופית', soundHint: 'ך', exampleWord: 'מלך', picture: 'emoji:👑', color: '#CA8A04', group: 5 },
];

export const LETTERS_BY_CHAR: Record<LetterChar, LetterData> = Object.fromEntries(
  ALL_LETTERS.map((l) => [l.char, l]),
);

export function getAllLetterChars(): LetterChar[] {
  return ALL_LETTERS.map((l) => l.char);
}

export function isFinalLetter(char: string): boolean {
  return ['ן', 'ם', 'ף', 'ץ', 'ך'].includes(char);
}

export function getUnlockedLetterChars(totalStars: number): Set<LetterChar> {
  const unlocked = new Set<LetterChar>();
  for (const g of LETTER_GROUPS) {
    if (totalStars >= g.unlockAtStars) {
      for (const c of g.letters) unlocked.add(c);
    }
  }
  return unlocked;
}
